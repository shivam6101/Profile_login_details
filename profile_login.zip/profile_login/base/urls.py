from django.urls import path
from .views import Profile,ProfileDetail,ProfileCreate,ProfileUpdate,ProfileDelete,ProfileLogin,ProfileRegister
from django.contrib.auth.views import LogoutView
urlpatterns = [
    path('login/',ProfileLogin.as_view(),name="login"),
    path('logout/',LogoutView.as_view(next_page='login'),name="logout"),
    path('profileregister/',ProfileRegister.as_view(),name="profileregister"),
    path('',Profile.as_view(),name="Profile"),
    path('profiledetail/<int:pk>/',ProfileDetail.as_view(),name="profiledetail"),
    path('profilecreate/',ProfileCreate.as_view(),name="profilecreate"),
    path('profileupdate/<int:pk>/',ProfileUpdate.as_view(),name="profileupdate"),
    path('profiledelete/<int:pk>/',ProfileDelete.as_view(),name="profiledelete"),
]
